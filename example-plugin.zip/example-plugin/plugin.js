// GeTools Plugin: Read URL
// Регистрирует команду [READ_URL: https://example.com]
// Gemini может использовать её чтобы прочитать содержимое страницы

window.getools.registerCommand('READ_URL', async (url) => {
  const trimmed = String(url || '').trim()
  if (!trimmed) return { success: false, error: 'URL не указан' }

  try {
    const res = await fetch(trimmed, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; GeTools/1.0)' }
    })

    if (!res.ok) {
      return { success: false, error: `HTTP ${res.status}: ${res.statusText}` }
    }

    const contentType = res.headers.get('content-type') || ''
    const text = await res.text()

    // Убираем HTML теги для читаемости
    const clean = contentType.includes('html')
      ? text
          .replace(/<script[\s\S]*?<\/script>/gi, '')
          .replace(/<style[\s\S]*?<\/style>/gi, '')
          .replace(/<[^>]+>/g, ' ')
          .replace(/\s{2,}/g, ' ')
          .trim()
          .slice(0, 8000)
      : text.slice(0, 8000)

    return {
      success: true,
      stdout: `URL: ${trimmed}\nДлина: ${text.length} символов\n\n${clean}`,
    }
  } catch (err) {
    return { success: false, error: err.message }
  }
}, {
  label: 'Читать URL',
  icon: 'link',
  description: 'Загружает и возвращает текст веб-страницы',
})

console.log('[GeTools Plugin] Read URL загружен')
